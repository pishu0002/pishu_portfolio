// Personal configuration adapted from arifszn/gitprofile. No live API calls.
// Professional facts: latest user work account, Dec 2025 review deck, LinkedIn, previous resume.
import type { Profile, Experience, Education, Project } from './src/interfaces/profile';

const CONFIG = {
  github: { username: 'pishu0002' },
  profile: {
    name: 'Prashanth Balaji', avatar: './prashanth-balaji.png',
    bio: 'Software Engineer', location: 'Work: Bengaluru · Hybrid', company: 'Philips',
  } satisfies Profile,
  social: { email: 'pishu0002@gmail.com', github: 'https://github.com/pishu0002', linkedin: 'https://www.linkedin.com/in/prashanth-balaji-1a2345254/' },
  resume: { fileUrl: './Prashanth_Balaji_Resume.pdf' },
  skills: [
    { title: 'Application development', items: ['JavaScript', 'Java', 'PHP', 'Ember.js', 'HTML / CSS', 'SQL', 'PostgreSQL'] },
    { title: 'Cloud & delivery', items: ['AWS', 'Kubernetes', 'Argo CD', 'Docker', 'CI/CD'] },
    { title: 'AI, integration & validation', items: ['LLM / RAG interfaces', 'AI usage monitoring', 'Azure OCR', 'Icon recognition', 'Image analysis', 'Automation keywords', 'Unit & integration testing'] },
  ],
  experiences: [
    {
      company: 'Philips', position: 'Software Engineer – I', from: 'Sep 2024', to: 'Present',
      type: 'Full-time', location: 'Bengaluru · Hybrid',
      summary: 'Working across AI application interfaces, image-analysis integrations, and release infrastructure for IRT, alongside full-stack development and ongoing operations.',
      bullets: [
        'Helped release IRT 2.0 to 3.0 by building enhanced Kubernetes and Argo CD infrastructure.',
        'Built user interfaces for LLM and retrieval-augmented generation (RAG) workflows in IRT 3.0, and a PostgreSQL-backed AI usage monitoring dashboard.',
        'Integrated Azure OCR for enhanced OCR capabilities and contributed to icon-recognition and image-analysis integrations.',
        'Developed automation keywords and supported validation and confidence-test workflows.',
        'Developed application interfaces and backend functionality; supported UI/backend releases, AWS operations, and infrastructure and server maintenance.',
        'Currently contributing to the artefact detection module (in progress).',
      ], tags: ['LLM / RAG interfaces', 'Azure OCR', 'Kubernetes', 'Argo CD', 'AWS', 'Full-stack development'],
    },
    {
      company: 'Philips', position: 'Software Engineer Intern', from: 'Aug 2023', to: 'Aug 2024',
      type: 'Internship',
      summary: 'Contributed to full-stack ultrasound reporting software and integration with related ultrasound projects.',
      bullets: ['Worked across frontend interfaces, backend functionality, SQL, and containerized development workflows.'],
      tags: ['PHP', 'JavaScript', 'Java', 'Ember.js', 'SQL', 'Docker'],
    },
  ] satisfies Experience[],
  educations: [{ institution: 'Vellore Institute of Technology', degree: 'Integrated M.Tech in Computer Science and Engineering', from: '2019', to: '2024' }] satisfies Education[],
  projects: [
    {
      id: 'agri', title: 'Agri Multiway Analyzer', category: 'ML & data', year: '2023', label: 'ACADEMIC PROJECT',
      description: 'An agriculture decision-support prototype exploring crop suitability, fertilizer suggestions, and plant-disease detection.',
      tags: ['Python', 'Flask', 'PyTorch'], link: 'https://github.com/pishu0002/agri-multiway-anlayzer',
      detail: 'The public repository combines machine-learning models with a Flask application, including a random-forest model and an image-classification model. This is an academic project based on an open-source implementation.',
      credit: 'Repository credits: Atharva Labhasetwar, Venkata Narayana Bommanaboina, and Kundan Patil. See the repository README for upstream attribution.',
    },
    {
      id: 'toxicity', title: 'Comment Toxicity Detection', category: 'ML & data', year: '2022', label: 'ACADEMIC PROJECT',
      description: 'A text-classification project exploring how deep learning can identify toxic language in online comments.',
      tags: ['Python', 'Deep learning', 'NLP'],
      detail: 'Explored vectorizing comment text and applying a deep-learning classifier to toxicity detection. The focus was processing comment text and exploring model-based classification.',
    },
    {
      id: 'kyc', title: 'E-KYC with Blockchain', category: 'Blockchain', year: '2022–23', label: 'ACADEMIC PROJECT',
      description: 'A prototype exploring a shared KYC workflow for banks through a distributed ledger.',
      tags: ['Solidity', 'Ganache', 'MetaMask'],
      detail: 'Explored a bank KYC workflow using blockchain tooling. The prototype uses Solidity, Ganache, and MetaMask; the emphasis was on understanding a shared identity workflow.',
    },
    {
      id: 'portfolio', title: 'Developer Portfolio', category: 'Web', year: '2026', label: 'PERSONAL WEBSITE',
      description: 'A professional home for my engineering experience, selected work, projects, and the tools I use.',
      tags: ['React', 'TypeScript', 'Vite'], link: 'https://github.com/pishu0002/pishu_portfolio',
      detail: 'This portfolio adapts GitProfile by Ariful Alam under its MIT license. It adds curated professional content, accessible project filters, light and dark themes, and a professional profile portrait.',
      credit: 'Template: arifszn/gitprofile. MIT license and source provenance are included with this portfolio.',
    },
  ] satisfies Project[],
};
export type Config = typeof CONFIG;
export default CONFIG;
