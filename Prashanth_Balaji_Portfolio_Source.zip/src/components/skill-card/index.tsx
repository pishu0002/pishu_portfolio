// Adapted from GitProfile SkillCard. Copyright (c) 2022 Ariful Alam, MIT.
const SkillCard=({skills}:{skills:{title:string;items:string[]}[]})=>(
  <section className="card skill-card" aria-labelledby="skills-heading"><div className="card-body"><p className="eyebrow">TOOLS I WORK WITH</p><h2 id="skills-heading">Across the stack.</h2>{skills.map(group=><div className="skill-group" key={group.title}><h3>{group.title}</h3><div className="tags">{group.items.map(skill=><span key={skill} className="badge">{skill}</span>)}</div></div>)}</div></section>
);
export default SkillCard;
