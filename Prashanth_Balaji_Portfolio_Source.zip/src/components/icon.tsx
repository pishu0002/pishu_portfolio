import type { CSSProperties } from 'react';
export type IconName = 'arrow' | 'down' | 'mail' | 'code' | 'cloud' | 'layers' | 'location' | 'briefcase' | 'education' | 'sun' | 'moon' | 'spark' | 'github' | 'linkedin' | 'check' | 'leaf' | 'message' | 'shield';
const paths: Record<IconName, string[]> = {
  arrow: ['M7 17 17 7M7 7h10v10'], down:['M12 3v12m-5-5 5 5 5-5M5 17v4h14v-4'],
  mail:['M3 5h18v14H3z','m3 6 9 7 9-7'], code:['m8 6-6 6 6 6m8-12 6 6-6 6m-3-15-2 18'],
  cloud:['M6 18a4 4 0 0 1-1-7.87A7 7 0 0 1 18.5 8a5 5 0 0 1 .5 10H6'],
  layers:['m12 3 10 6-10 6L2 9z','m2 13 10 6 10-6m-20 4 10 6 10-6'],
  location:['M19 10c0 5-7 11-7 11S5 15 5 10a7 7 0 0 1 14 0Z','M14.5 10a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0'],
  briefcase:['M3 7h18v14H3zM8 7V3h8v4','M3 12c6 4 12 4 18 0m-9 1v4'],
  education:['m2 8 10-5 10 5-10 5z','M6 10v7c4 4 8 4 12 0v-7m4-2v10'],
  sun:['M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.5 1.5m11 11L19 19M5 19l1.5-1.5m11-11L19 5','M17 12a5 5 0 1 1-10 0 5 5 0 0 1 10 0'],
  moon:['M21 13A9 9 0 0 1 11 3a9 9 0 1 0 10 10'],
  spark:['m12 2 2.8 7.2L22 12l-7.2 2.8L12 22l-2.8-7.2L2 12l7.2-2.8z'],
  github:['M9 19c-5 1.5-5-2.5-7-3m14 6v-4a3.5 3.5 0 0 0-1-2.8c3.3-.4 6.7-1.6 6.7-7.3a5.7 5.7 0 0 0-1.5-4A5.3 5.3 0 0 0 20 0s-1.3-.4-4.5 1.5a15.5 15.5 0 0 0-8 0C4.3-.4 3 0 3 0a5.3 5.3 0 0 0-.2 3.9 5.7 5.7 0 0 0-1.5 4c0 5.7 3.4 6.9 6.7 7.3A3.5 3.5 0 0 0 7 18v4'],
  linkedin:['M4 9v12m0-17v.1M10 21V9h5v2c2-4 7-2 7 2v8m-7-7v7'],
  check:['m5 12 4 4L19 6'], leaf:['M20 3C8 2 2 8 5 15s16 5 15-12ZM5 19 16 8'],
  message:['M3 3h18v14H8l-5 4z','M7 8h10M7 12h6'], shield:['m12 2 9 4v6c0 6-9 10-9 10S3 18 3 12V6z','m8 12 3 3 5-6'],
};
export default function Icon({name,size=20,style}:{name:IconName;size?:number;style?:CSSProperties}){
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" style={style}>{paths[name].map((d,i)=><path key={i} d={d}/>)}</svg>;
}
