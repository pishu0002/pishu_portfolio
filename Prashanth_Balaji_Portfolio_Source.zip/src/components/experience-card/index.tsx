// Adapted from GitProfile ExperienceCard/ListItem. Copyright (c) 2022 Ariful Alam, MIT.
import type { Experience } from '../../interfaces/profile';
import Icon from '../icon';
const ListItem = ({experience,index}:{experience:Experience;index:number}) => (
  <li className={`experience-item ${index===0?'current':''}`}>
    <div className="timeline-dot" aria-hidden="true"/>
    <div className="experience-title"><div><div className="experience-date">{experience.from} — {experience.to}</div><h3>{experience.position}</h3><p className="company-name">{experience.company}<span>· {experience.type}</span></p></div>{index===0&&<span className="pill current-pill">Current role</span>}</div>
    <p className="experience-summary">{experience.summary}</p>
    <ul className="experience-bullets">{experience.bullets.map(bullet=><li key={bullet}>{bullet}</li>)}</ul>
    <div className="tags">{experience.tags.map(tag=><span className="badge" key={tag}>{tag}</span>)}</div>
  </li>
);
const ExperienceCard = ({experiences}:{experiences:Experience[]}) => (
  <section id="experience" className="card experience-card" aria-labelledby="experience-heading"><div className="card-body"><div className="section-title"><div className="heading-icon"><Icon name="briefcase"/></div><div><p className="eyebrow">THE PROFESSIONAL JOURNEY</p><h2 id="experience-heading">Experience</h2></div><span className="section-number">01</span></div><ol className="experience-timeline">{experiences.map((experience,index)=><ListItem key={`${experience.company}-${experience.from}`} experience={experience} index={index}/>)}</ol></div></section>
);
export default ExperienceCard;
