// Adapted from GitProfile EducationCard/ListItem. Copyright (c) 2022 Ariful Alam, MIT.
import type { Education } from '../../interfaces/profile';
import Icon from '../icon';
const ListItem = ({item}:{item:Education}) => <li className="education-item"><div className="education-date">{item.from} — {item.to}</div><h3>{item.degree}</h3><p>{item.institution}</p></li>;
const EducationCard = ({educations}:{educations:Education[]}) => (
  <section className="card education-card" aria-labelledby="education-heading"><div className="card-body"><div className="section-title"><div className="heading-icon"><Icon name="education"/></div><div><p className="eyebrow">THE FOUNDATION</p><h2 id="education-heading">Education</h2></div></div><ol>{educations.map(item=><ListItem key={`${item.institution}-${item.from}`} item={item}/>)}</ol></div></section>
);
export default EducationCard;
