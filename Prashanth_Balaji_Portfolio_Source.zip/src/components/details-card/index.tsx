import Icon from '../icon';
const DetailsCard=({social}:{social:{github:string;linkedin:string;email:string}})=>(
  <section className="card details-card" aria-label="Find me online"><div className="card-body"><p className="eyebrow">ELSEWHERE ON THE INTERNET</p><a href={social.github} target="_blank" rel="noopener noreferrer"><Icon name="github" size={18}/><span>GitHub<small>@pishu0002</small></span><Icon name="arrow" size={16}/><span className="sr-only"> (opens in a new tab)</span></a><a href={social.linkedin} target="_blank" rel="noopener noreferrer"><Icon name="linkedin" size={18}/><span>LinkedIn<small>Let’s connect</small></span><Icon name="arrow" size={16}/><span className="sr-only"> (opens in a new tab)</span></a></div></section>
);
export default DetailsCard;
