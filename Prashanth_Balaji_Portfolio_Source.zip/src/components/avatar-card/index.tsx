// Adapted from GitProfile AvatarCard, Copyright (c) 2022 Ariful Alam, MIT.
// Retains the profile/avatar/resume card; local content replaces loading/API state.
import type { Profile } from '../../interfaces/profile';
import Icon from '../icon';
interface AvatarCardProps { profile: Profile; resumeFileUrl?: string; email: string; }
const AvatarCard = ({profile,resumeFileUrl,email}:AvatarCardProps) => (
  <section className="card avatar-card" aria-label="Profile">
    <div className="avatar-banner" aria-hidden="true"><span>PB</span><i/><i/><i/></div>
    <div className="card-body">
      <div className="avatar"><img src={profile.avatar} alt="Prashanth Balaji, professional portrait" width="160" height="160" fetchPriority="high"/></div>
      <div className="identity"><div className="role-status"><span/> ENGINEERING AT PHILIPS</div><h1>{profile.name}</h1><p className="profile-bio">{profile.bio}</p><p className="profile-location"><Icon name="location" size={14}/>{profile.location}</p></div>
      <p className="profile-summary">I connect AI application interfaces, image analysis, and cloud delivery.</p>
      <div className="profile-actions"><a className="button primary" href={`mailto:${email}`}><Icon name="mail" size={16}/> Get in touch <Icon name="arrow" size={16}/></a>{resumeFileUrl && <a className="button secondary" href={resumeFileUrl} download><Icon name="down" size={16}/> Download résumé</a>}</div>
    </div>
  </section>
);
export default AvatarCard;
