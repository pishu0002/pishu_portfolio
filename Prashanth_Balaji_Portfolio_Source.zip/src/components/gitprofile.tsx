// Adapted from GitProfile card-grid composition, Copyright (c) 2022 Ariful Alam, MIT.
// Curated local configuration replaces upstream GitHub fetching and analytics.
import { useEffect, useState } from 'react';
import type { Config } from '../../gitprofile.config';
import type { Project } from '../interfaces/profile';
import AvatarCard from './avatar-card';
import DetailsCard from './details-card';
import SkillCard from './skill-card';
import ExperienceCard from './experience-card';
import EducationCard from './education-card';
import ThemeChanger from './theme-changer';
import Footer from './footer';
import Icon, { type IconName } from './icon';
import '../assets/index.css';

const work = [
  { icon: 'cloud' as IconName, title: 'IRT release infrastructure', type: 'KUBERNETES & ARGO CD', copy: 'Supporting the move from IRT 2.0 to 3.0.', detail: 'Helped release IRT 2.0 to 3.0 by building enhanced Kubernetes and Argo CD infrastructure. Contributed to Argo CD sync controls for shared jobs and supported deployment workflows and delivery environments, alongside AWS operations, server maintenance, and ongoing infrastructure upkeep.' },
  { icon: 'spark' as IconName, title: 'AI interfaces & monitoring', type: 'LLM / RAG APPLICATIONS', copy: 'Building interfaces for AI workflows and usage visibility.', detail: 'Built user interfaces for LLM and retrieval-augmented generation (RAG) workflows in IRT 3.0. Implemented media uploads, dynamic analysis configuration, AI-assisted recommendations, job monitoring, and result preview/download workflows. Built a PostgreSQL-backed dashboard for AI usage and adoption reporting, including admin data management and audit history.' },
  { icon: 'layers' as IconName, title: 'Azure OCR & recognition', type: 'IMAGE-ANALYSIS INTEGRATION', copy: 'Connecting OCR and recognition capabilities to tools.', detail: 'Integrated Azure OCR with model selection, compatible OCR outputs, bounding-box handling, and enhanced value-matching integration. Contributed to icon-recognition, area-detection, and OCR module integration, connecting image-analysis functionality with application workflows.' },
  { icon: 'check' as IconName, title: 'Automation & validation', type: 'AUTOMATION KEYWORDS', copy: 'Extending automation and repeatable validation.', detail: 'Developed automation keywords, addressed failing keywords, and supported validation and confidence-test workflows. Migrated icon, image, and frame-speed analysis modules with unit and integration validation, and automated confidence-test triggers.' },
  { icon: 'code' as IconName, title: 'Full-stack application work', type: 'UI & BACKEND DEVELOPMENT', copy: 'Connecting interfaces, services, and software releases.', detail: 'Rebuilt an internal customer-issue tool interface and connected backend functionality, including system/year filtering and recurring-issue features. Improved a results viewer with text-handling fixes and hyperlink enhancements. Contributed to an application-server analysis UI and session-upload workflow, troubleshooting HTTPS ingress uploads with end-to-end verification. Supported containerization, server-side development, and UI/backend releases.' },
  { icon: 'layers' as IconName, title: 'Artefact detection', type: 'IN PROGRESS', copy: 'Contributing to the artefact detection module.', detail: 'Currently contributing to the artefact detection module. This work is in progress.' },
];

function ProjectArt({id}:{id:string}) {
  return <div className={`project-art art-${id}`} aria-hidden="true">
    {id==='agri'&&<><div className="art-orbit orbit-one"/><div className="art-orbit orbit-two"/><div className="art-symbol"><Icon name="leaf" size={47}/></div><div className="art-caption">CROP <span>·</span> SOIL <span>·</span> DISEASE</div></>}
    {id==='toxicity'&&<><div className="comment-bubble"><span/><span/><span/></div><div className="classification"><Icon name="message" size={15}/><b>Text</b><i>→</i><b>Model</b><i>→</i><b>Classify</b></div></>}
    {id==='kyc'&&<><div className="ledger-chain"><span/><i/><span><Icon name="shield" size={32}/></span><i/><span/></div><div className="art-caption">IDENTITY <span>·</span> SHARED LEDGER</div></>}
    {id==='portfolio'&&<><div className="browser-art"><div className="browser-bar"><i/><i/><i/></div><div className="browser-layout"><div>pb.</div><span><i/><i/><i/></span></div></div><span className="art-code">&lt;portfolio /&gt;</span></>}
  </div>;
}
function ProjectCard({project}:{project:Project}) {
  return <article className="project-card"><ProjectArt id={project.id}/><div className="project-copy"><div className="project-meta"><span>{project.label}</span><span>{project.year}</span></div><h3>{project.title}</h3><p>{project.description}</p><div className="tags">{project.tags.map(tag=><span className="badge" key={tag}>{tag}</span>)}</div><div className="project-links">{project.link&&<a href={project.link} target="_blank" rel="noopener noreferrer">{project.id==='portfolio'?'Source repository':'View source'} <Icon name="arrow" size={15}/><span className="sr-only"> for {project.title} (opens in a new tab)</span></a>}<details><summary>Project details <span aria-hidden="true">+</span></summary><div className="project-detail"><p>{project.detail}</p>{project.credit&&<p className="project-credit">{project.credit}</p>}</div></details></div></div></article>;
}
function GitProfile({config}:{config:Config}) {
  const [theme,setTheme]=useState<string>(()=>{try{return localStorage.getItem('prashanth-portfolio-theme')==='dark'?'dark':'light';}catch{return 'light';}});
  const [filter,setFilter]=useState('All projects');
  useEffect(()=>{document.documentElement.setAttribute('data-theme',theme);try{localStorage.setItem('prashanth-portfolio-theme',theme);}catch{/* Theme still works with browser storage disabled. */}},[theme]);
  const shown=config.projects.filter(project=>filter==='All projects'||project.category===filter);
  return <div id="top"><a className="skip-link" href="#main">Skip to content</a>
    <header className="site-header"><a className="brand" href="#top" aria-label="Prashanth Balaji, home"><span>pb.</span><div>PRASHANTH BALAJI<small>SOFTWARE ENGINEER</small></div></a><nav aria-label="Main navigation"><a href="#experience">Experience</a><a href="#projects">Projects</a><a href="#about">About</a></nav><ThemeChanger theme={theme} setTheme={setTheme}/></header>
    <div className="dashboard-grid">
      <aside className="sidebar"><AvatarCard profile={config.profile} resumeFileUrl={config.resume.fileUrl} email={config.social.email}/><DetailsCard social={config.social}/><SkillCard skills={config.skills}/><div className="sidebar-note"><Icon name="spark" size={22}/><p>Curious about the feature.<br/>Thoughtful about the system.</p></div></aside>
      <main id="main" className="main-column">
        <section className="hero-card" aria-labelledby="intro-title"><div className="hero-orbit" aria-hidden="true"/><div className="hero-kicker"><span className="tiny-dot"/> FULL-STACK DEVELOPMENT & CLOUD DELIVERY</div><h2 id="intro-title">Software, from UI<br/>to <span>infrastructure.</span></h2><p>I’m Prashanth, a software engineer at Philips. My work spans LLM/RAG interfaces, image-analysis integrations, and Kubernetes and Argo CD release infrastructure.</p><a href="#experience" className="hero-link">Explore my experience <Icon name="arrow" size={17}/></a><div className="hero-bottom"><span><Icon name="code" size={17}/> Build</span><i/><span><Icon name="layers" size={17}/> Integrate</span><i/><span><Icon name="cloud" size={17}/> Release</span></div></section>
        <ExperienceCard experiences={config.experiences}/>
        <section className="card work-card" aria-labelledby="work-heading"><div className="card-body"><div className="section-title"><div className="heading-icon"><Icon name="layers"/></div><div><p className="eyebrow">A CLOSER LOOK</p><h2 id="work-heading">Selected work</h2></div><span className="section-number">02</span></div><div className="work-grid">{work.map((item,index)=><details className="work-detail" key={item.title}><summary><span className={`work-icon work-icon-${index%3}`}><Icon name={item.icon} size={23}/></span><small>{item.type}</small><h3>{item.title}</h3><p>{item.copy}</p><span className="work-expand">Explore contribution <b aria-hidden="true">+</b></span></summary><p className="work-expanded-copy">{item.detail}</p></details>)}</div></div></section>
        <section id="projects" className="card projects-card" aria-labelledby="projects-heading"><div className="card-body"><div className="section-title"><div className="heading-icon"><Icon name="code"/></div><div><p className="eyebrow">LEARNING BY BUILDING</p><h2 id="projects-heading">Projects & experiments</h2></div><span className="section-number">03</span></div><div className="project-toolbar"><div className="filters" aria-label="Filter projects">{['All projects','ML & data','Blockchain','Web'].map(option=><button key={option} onClick={()=>setFilter(option)} aria-pressed={filter===option}>{option}</button>)}</div><span className="project-count" aria-live="polite">{shown.length} projects</span></div><div className="project-grid">{shown.map(project=><ProjectCard project={project} key={project.id}/>)}</div><a className="github-all" href="https://github.com/pishu0002?tab=repositories" target="_blank" rel="noopener noreferrer">More on GitHub <Icon name="arrow" size={15}/><span className="sr-only"> (opens in a new tab)</span></a></div></section>
        <div id="about" className="about-grid"><section className="card about-card" aria-labelledby="about-heading"><div className="card-body"><p className="eyebrow">A LITTLE ABOUT ME</p><h2 id="about-heading">The connections<br/>are the interesting part.</h2><p>From ultrasound reporting software to LLM/RAG interfaces, image analysis, and release infrastructure, I’ve enjoyed understanding how the pieces of a product fit together.</p><p>I like practical engineering: understanding a feature, connecting its parts, validating the result, and supporting it through release.</p></div></section><EducationCard educations={config.educations}/></div>
        <section className="contact-card" aria-labelledby="contact-heading"><div><p className="eyebrow">SAY HELLO</p><h2 id="contact-heading">Have something in mind?</h2><p>Let’s talk about software, systems, and useful things to build.</p><a href={`mailto:${config.social.email}`}>{config.social.email}<Icon name="arrow" size={20}/></a></div><div className="contact-symbol" aria-hidden="true"><Icon name="arrow" size={65}/></div></section>
      </main>
    </div><Footer/>
  </div>;
}
export default GitProfile;