import Icon from '../icon';
export default function ThemeChanger({theme,setTheme}:{theme:string;setTheme:(theme:string)=>void}){
  return <button className="theme-toggle" type="button" onClick={()=>setTheme(theme==='dark'?'light':'dark')} aria-label={`Switch to ${theme==='dark'?'light':'dark'} theme`} title={`Switch to ${theme==='dark'?'light':'dark'} theme`}><Icon name={theme==='dark'?'sun':'moon'} size={18}/></button>;
}
