// Adapted from GitProfile, Copyright (c) 2022 Ariful Alam. MIT; see LICENSE.
import React from 'react';
import ReactDOM from 'react-dom/client';
import GitProfile from './components/gitprofile';
import CONFIG from '../gitprofile.config';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode><GitProfile config={CONFIG} /></React.StrictMode>,
);
