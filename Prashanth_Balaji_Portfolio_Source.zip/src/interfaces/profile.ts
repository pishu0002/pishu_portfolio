export interface Profile {
  name: string; avatar: string; bio: string; location: string; company: string;
}
export interface Experience {
  company: string; position: string; from: string; to: string; type: string;
  location?: string; summary: string; bullets: string[]; tags: string[];
}
export interface Education { institution: string; degree: string; from: string; to: string; }
export interface Project {
  id: string; title: string; category: string; year: string; label: string;
  description: string; tags: string[]; link?: string; detail: string; credit?: string;
}
