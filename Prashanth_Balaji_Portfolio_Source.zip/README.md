# Editable portfolio source — Prashanth Balaji

This is the complete editable source for the React/TypeScript portfolio adapted from [arifszn/gitprofile](https://github.com/arifszn/gitprofile). The published website is [pishu0002.github.io/pishu_portfolio](https://pishu0002.github.io/pishu_portfolio/).

## Develop and build

Use Node.js 24 LTS (tested with 24.19.0) and a current npm version:

```sh
npm ci
npm run dev
npm run build
```

The production files are generated in `dist/`. Vite uses `base: './'` and `assetsDir: '.'` so the entire release is a flat root directory that works under a GitHub Pages repository subpath. `npm run preview` serves the production build for verification. Do not open the React build through `file://`; serve it over HTTP.

The resume is included at `public/Prashanth_Balaji_Resume.pdf` and is copied to the built root. The download link `./Prashanth_Balaji_Resume.pdf` works in development, preview, and the published site. Replace the PDF in `public/` and rebuild to update it.

## Edit content

- `gitprofile.config.ts`: professional facts, skills, experience, education, projects, and links.
- `src/components/gitprofile.tsx`: main layout and selected-work case studies.
- `src/assets/index.css`: styling, themes, responsive layouts, and print treatment.
- `public/prashanth-balaji.png`: professional portrait.

The application uses local curated content rather than live GitHub fetching. There are no trackers, API keys, external fonts, or runtime data-service dependencies. Theme preference uses browser local storage only.

## Attribution

GitProfile source commit `0e58cd05cc68a1295694fc2003cf282c08c8f781`, Copyright (c) 2022 Ariful Alam, MIT license. The full license is included here and in `public/` so it accompanies each build. Executable adapted components retain source comments; their originals are included in `upstream-reference/` for traceability and are excluded from TypeScript compilation.

This source archive omits `node_modules` and generated `dist` output. Academic project credit and ongoing-work status remain part of the website content.