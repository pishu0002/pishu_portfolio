import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Relative asset URLs also work below a GitHub Pages repository path.
export default defineConfig({ base: './', plugins: [react()], build: { outDir: 'dist', assetsDir: '.' } });
